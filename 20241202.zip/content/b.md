+++
date = '2024-11-21T14:06:31+02:00'
draft = true
title = 'B'
someval = 'me here write'
+++

![](/elephant.jpg)

E

![](https://cdn.pixabay.com/photo/2024/02/28/07/42/european-shorthair-8601492_640.jpg)
