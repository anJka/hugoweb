---
date: 2024-12-02T20:29:01+02:00
draft: false
title: About 10
url: /about/
someval: me here write
weight: 10
---
