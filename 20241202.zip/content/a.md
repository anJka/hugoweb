+++
date = '2024-11-21T10:43:19+02:00'
draft = true
title = 'A'
tags = ["tag1","tag2"]
moods = ["happy"]
+++

{{% comment %}} TODO: rewrite the paragraph below. THIS TEXT WILL NOT SHOW {{% /comment %}}

{{< figure src="/elephant.jpg" title="An elephant at sunset" caption="c" attrlink="http://google.lt/" >}}

{{< myshortcode var="/elephant.jpg" >}}

{{< youtube 2xkNJL4gJ9E >}}
